package com.aht.angularApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularApiApplication.class, args);
	}

}
