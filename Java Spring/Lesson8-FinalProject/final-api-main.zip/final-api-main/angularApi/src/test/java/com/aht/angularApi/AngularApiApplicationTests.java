package com.aht.angularApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
